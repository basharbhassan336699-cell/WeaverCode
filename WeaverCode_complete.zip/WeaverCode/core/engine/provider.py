"""
provider.py — محرك الاتصال بمزودي النماذج
يدعم أي مزود يتبع معيار OpenAI API أو Anthropic API
"""

import os
import json
import httpx
from typing import AsyncGenerator, Optional, Dict, Any, List
from dataclasses import dataclass, field


@dataclass
class Message:
    role: str  # user | assistant | system | tool
    content: str
    tool_calls: Optional[List[Dict]] = None
    tool_call_id: Optional[str] = None
    name: Optional[str] = None


@dataclass
class ProviderConfig:
    api_key: str
    base_url: str
    model: str
    max_tokens: int = 8192
    temperature: float = 0.7
    extra_headers: Dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_env(cls) -> "ProviderConfig":
        """تحميل الإعدادات من متغيرات البيئة"""
        return cls(
            api_key=os.environ.get("WEAVER_API_KEY", ""),
            base_url=os.environ.get("WEAVER_BASE_URL", "https://openrouter.ai/api/v1"),
            model=os.environ.get("WEAVER_MODEL", "anthropic/claude-sonnet-4-6"),
            max_tokens=int(os.environ.get("WEAVER_MAX_TOKENS", "8192")),
            temperature=float(os.environ.get("WEAVER_TEMPERATURE", "0.7")),
        )


class WeaverProvider:
    """
    موصل عالمي لأي مزود نماذج ذكاء اصطناعي
    يتبع معيار OpenAI Chat Completions API
    """

    def __init__(self, config: Optional[ProviderConfig] = None):
        self.config = config or ProviderConfig.from_env()
        self._client = httpx.AsyncClient(
            base_url=self.config.base_url,
            headers={
                "Authorization": f"Bearer {self.config.api_key}",
                "Content-Type": "application/json",
                **self.config.extra_headers,
            },
            timeout=120.0,
        )

    def _is_anthropic_native(self) -> bool:
        """هل المزود يستخدم Anthropic API الأصلي (لا OpenAI-compat)؟"""
        return "anthropic.com" in self.config.base_url and "/v1" in self.config.base_url

    def _build_openai_payload(
        self,
        messages: List[Message],
        tools: Optional[List[Dict]] = None,
        stream: bool = False,
    ) -> Dict[str, Any]:
        """بناء الـ payload بصيغة OpenAI"""
        payload: Dict[str, Any] = {
            "model": self.config.model,
            "messages": [self._msg_to_openai(m) for m in messages],
            "max_tokens": self.config.max_tokens,
            "temperature": self.config.temperature,
            "stream": stream,
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
        return payload

    def _msg_to_openai(self, msg: Message) -> Dict:
        """تحويل Message إلى صيغة OpenAI"""
        d: Dict[str, Any] = {"role": msg.role, "content": msg.content}
        if msg.tool_calls:
            d["tool_calls"] = msg.tool_calls
        if msg.tool_call_id:
            d["tool_call_id"] = msg.tool_call_id
        if msg.name:
            d["name"] = msg.name
        return d

    async def complete(
        self,
        messages: List[Message],
        tools: Optional[List[Dict]] = None,
    ) -> Dict[str, Any]:
        """استدعاء غير متدفق — يرجع الرد كاملاً"""
        payload = self._build_openai_payload(messages, tools, stream=False)
        resp = await self._client.post("/chat/completions", json=payload)
        resp.raise_for_status()
        return resp.json()

    async def stream(
        self,
        messages: List[Message],
        tools: Optional[List[Dict]] = None,
    ) -> AsyncGenerator[str, None]:
        """استدعاء متدفق — يرجع أجزاء النص تباعاً"""
        payload = self._build_openai_payload(messages, tools, stream=True)
        async with self._client.stream("POST", "/chat/completions", json=payload) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if line.startswith("data: "):
                    chunk = line[6:]
                    if chunk == "[DONE]":
                        break
                    try:
                        data = json.loads(chunk)
                        delta = data["choices"][0]["delta"]
                        if "content" in delta and delta["content"]:
                            yield delta["content"]
                    except (json.JSONDecodeError, KeyError):
                        continue

    async def close(self):
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()


def get_provider(
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    model: Optional[str] = None,
    **kwargs,
) -> WeaverProvider:
    """
    مصنع مريح للحصول على مزود جاهز
    الأولوية: المعاملات > متغيرات البيئة
    """
    config = ProviderConfig.from_env()
    if api_key:
        config.api_key = api_key
    if base_url:
        config.base_url = base_url
    if model:
        config.model = model
    for k, v in kwargs.items():
        if hasattr(config, k):
            setattr(config, k, v)
    return WeaverProvider(config)
