<div align="center">

<img src="assets/icon_store_dark.png" width="180" alt="WeaverCode Logo"/>

# 🕸️ WeaverCode

**وكيل برمجي ذكي ومستقل — يعمل مع أي نموذج AI من أي شركة**

[![Python](https://img.shields.io/badge/Python-3.10+-blue?style=flat-square&logo=python)](https://python.org)
[![License](https://img.shields.io/badge/License-MIT-orange?style=flat-square)](LICENSE)
[![Platform](https://img.shields.io/badge/Platform-Linux%20%7C%20Android%2FTermux-green?style=flat-square)](https://termux.dev)
[![Models](https://img.shields.io/badge/Models-Any%20OpenAI--Compatible-purple?style=flat-square)](config/.env.example)

</div>

---

## ما هو WeaverCode؟

WeaverCode وكيل برمجي يعمل من سطر الأوامر — يقرأ كودك، يعدّل الملفات، ينفّذ الأوامر، ويدير مشاريعك بالكامل عبر اللغة الطبيعية.

**الفرق الجوهري:** لا يتبع أي شركة. ضع مفتاح أي نموذج وهو يعمل.

```
أنت → WeaverCode → [أي نموذج AI] → النتيجة
```

---

## المزودون المدعومون

| المزود | الموديل الافتراضي | مجاني؟ |
|--------|-----------------|--------|
| **OpenRouter** | claude-sonnet-4-6 | جزئياً |
| **Groq** | llama-3.3-70b | ✅ |
| **DeepSeek** | deepseek-chat | رخيص |
| **Anthropic** | claude-sonnet-4-6 | ❌ |
| **OpenAI** | gpt-4o | ❌ |
| **Ollama** | llama3.2 | ✅ محلي |

---

## تثبيت سريع

```bash
# استنساخ المشروع
git clone https://github.com/basharbhassan336699-cell/WeaverCode
cd WeaverCode

# تثبيت التبعيات
pip install -r config/requirements.txt --break-system-packages

# إعداد المفتاح
cp config/.env.example config/.env
nano config/.env   # ← ضع مفتاحك هنا

# تشغيل
python3 weaver.py "مرحباً"
```

### على Termux (Android)
```bash
bash scripts/install_termux.sh
```

---

## الاستخدام

```bash
# مهمة واحدة
python3 weaver.py "اقرأ ملف README.md وأخبرني بمحتواه"

# وضع تفاعلي
python3 weaver.py --interactive

# وضع متخصص
python3 weaver.py --mode coding "راجع كود provider.py"
python3 weaver.py --mode security "افحص المشروع أمنياً"

# تبديل النموذج مؤقتاً
python3 weaver.py --model "llama-3.3-70b" --url "https://api.groq.com/openai/v1" --key "gsk_..." "مهمتك"
```

---

## الأدوات المدمجة (44 أداة)

<details>
<summary>عرض القائمة الكاملة</summary>

| الفئة | الأدوات |
|-------|---------|
| **الملفات** | Read, Write, Edit, Glob, Grep |
| **التنفيذ** | Bash, Monitor |
| **الذاكرة** | MemorySave, MemorySearch, MemoryDelete, MemoryList |
| **المهام** | TaskCreate, TaskList, TaskUpdate |
| **الويب** | WebFetch, WebSearch |
| **Git** | GitStatus, GitClone, GitCommit, GitPush |
| **Python** | PipInstall, PythonRun |
| **النظام** | EnvSet, EnvGet, DirectoryList, AskUser |
| **الوكلاء** | Agent, CronCreate, CronList, CronDelete |
| **التخطيط** | EnterPlanMode, ExitPlanMode |
| **Jupyter** | NotebookEdit |
| **الكود** | LSP, ReportFindings |
| **الإخراج** | SendUserFile, PushNotification, ToolSearch |
| **Git Worktree** | EnterWorktree, ExitWorktree |

</details>

---

## أوامر Claude Code المدمجة

```
/setup          ← إعداد WeaverCode للمرة الأولى
/build          ← بناء وتطوير ميزات جديدة
/expand-tools   ← تثبيت الأدوات الناقصة
/clone-deps     ← استنساخ المستودعات المرجعية
/switch-model   ← تبديل نموذج AI
/review         ← مراجعة الكود
```

---

## الأيقونات

<div align="center">
<img src="assets/icon_256x256.png" width="80"/>
<img src="assets/icon_store_dark.png" width="80"/>
<img src="assets/icon_store_light.png" width="80"/>
</div>

---

## هيكل المشروع

```
WeaverCode/
├── weaver.py              ← نقطة الدخول
├── CLAUDE.md              ← ذاكرة المشروع
├── assets/                ← الأيقونات (15 ملف)
├── core/
│   ├── engine/
│   │   ├── provider.py    ← موصل أي API
│   │   └── query_engine.py← المحرك الوكيلي
│   ├── tools/
│   │   └── registry.py    ← 44 أداة مدمجة
│   └── memory/
│       └── store.py       ← ذاكرة SQLite
├── prompts/
│   └── system.py          ← 6 بروموهات متخصصة
├── .claude/commands/      ← 6 أوامر Claude Code
├── config/
│   ├── .env.example
│   └── requirements.txt
└── scripts/
    ├── expand_tools.py
    ├── init_github.sh
    └── install_termux.sh
```

---

## المطور

**Bashar** — UAE  
مشروع مفتوح المصدر، مبني بالكامل بمساعدة Claude.

---

<div align="center">
<img src="assets/icon_internal_64.png" width="40"/>
<br/>
<sub>🕸️ WeaverCode — ينسج الكود كالعنكبوت</sub>
</div>
