#!/usr/bin/env python3
"""
weaver.py — نقطة الدخول الرئيسية لـ WeaverCode
الاستخدام:
    python weaver.py "مهمتك هنا"
    python weaver.py --mode coding "راجع هذا الكود"
    python weaver.py --stream "اكتب سكربت Python"
    python weaver.py --interactive
"""

import asyncio
import argparse
import os
import sys
from pathlib import Path

# إضافة المشروع للمسار
sys.path.insert(0, str(Path(__file__).parent))

from core.engine.provider import get_provider
from core.engine.query_engine import QueryEngine
from core.tools.registry import ToolRegistry
from core.memory.store import MemoryStore
from prompts.system import get_system_prompt
from core.ui import (
    show_banner, show_mini_banner, format_tool_call,
    format_response, format_error, format_success,
    format_info, print_stats, show_startup_icon,
    ORANGE, GRAY, RESET, BOLD
)


def load_env():
    """تحميل متغيرات البيئة من .env إن وجد"""
    env_file = Path(__file__).parent / "config" / ".env"
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, _, val = line.partition("=")
                os.environ.setdefault(key.strip(), val.strip())


async def run_once(prompt: str, mode: str = "main", stream: bool = False):
    """تشغيل مهمة واحدة"""
    load_env()

    provider = get_provider()
    memory = MemoryStore()
    tools = ToolRegistry()
    system = get_system_prompt(mode)

    engine = QueryEngine(
        provider=provider,
        tool_registry=tools,
        memory=memory,
        system_prompt=system,
    )

    show_banner(provider.config.model, provider.config.base_url)

    if stream:
        print(f"{ORANGE}🕸️{RESET}  ", end="", flush=True)
        async for chunk in engine.stream_run(prompt):
            print(chunk, end="", flush=True)
        print("\n")
    else:
        def on_text(text):
            pass

        def on_tool(name, args):
            key_arg = str(list(args.values())[0]) if args else ""
            print(format_tool_call(name, key_arg))

        result = await engine.run(prompt, on_text=on_text, on_tool=on_tool)

        if result.error:
            print(format_error(result.error))
        else:
            print(format_response(result.text))
            if result.tool_calls_made:
                print_stats(result.turns, result.tool_calls_made)

    await provider.close()


async def interactive_mode():
    """وضع المحادثة التفاعلية"""
    load_env()

    provider = get_provider()
    memory = MemoryStore()
    tools = ToolRegistry()
    engine = QueryEngine(provider=provider, tool_registry=tools, memory=memory)

    show_startup_icon()
    show_banner(provider.config.model, provider.config.base_url)
    print(f"{GRAY}اكتب 'خروج' للإنهاء | '/mode <mode>' لتغيير الوضع | '/model <name>' لتبديل النموذج{RESET}")
    print(f"{GRAY}{'─' * 50}{RESET}")

    history = []

    while True:
        try:
            prompt = input(f"\n{ORANGE}👤{RESET} أنت: ").strip()
        except (EOFError, KeyboardInterrupt):
            print(f"\n\n{ORANGE}🕸️  إلى اللقاء!{RESET}")
            break

        if not prompt:
            continue

        if prompt.lower() in ("خروج", "exit", "quit"):
            print(f"{ORANGE}🕸️  إلى اللقاء!{RESET}")
            break

        if prompt.startswith("/mode "):
            mode = prompt[6:].strip()
            engine.system_prompt = get_system_prompt(mode)
            print(format_success(f"الوضع: {mode}"))
            continue

        if prompt.startswith("/model "):
            model = prompt[7:].strip()
            provider.config.model = model
            print(format_success(f"النموذج: {model}"))
            continue

        if prompt.startswith("/icon"):
            show_startup_icon()
            continue

        if prompt.startswith("/stats"):
            stats = engine.memory.get_stats()
            print(format_info(f"محادثات محفوظة: {stats['conversations']} | حقائق: {stats['facts']}"))
            continue

        def on_tool(name, args):
            key_arg = str(list(args.values())[0]) if args else ""
            print(format_tool_call(name, key_arg))

        result = await engine.run(prompt, history=history, on_tool=on_tool)

        if result.error:
            print(format_error(result.error))
        else:
            print(format_response(result.text))
            if result.tool_calls_made:
                print_stats(result.turns, result.tool_calls_made)

    await provider.close()


def main():
    parser = argparse.ArgumentParser(
        description="WeaverCode — وكيل برمجي مستقل",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
أمثلة:
  python weaver.py "اقرأ ملف README.md"
  python weaver.py --mode coding "راجع كود provider.py"
  python weaver.py --stream "اشرح بنية المشروع"
  python weaver.py --interactive
  python weaver.py --model "gpt-4o" "مهمتك"
        """,
    )
    parser.add_argument("prompt", nargs="?", help="المهمة المطلوبة")
    parser.add_argument("--mode", default="main",
                        choices=["main", "coding", "project", "security", "autonomous", "analysis"],
                        help="وضع عمل الوكيل")
    parser.add_argument("--stream", action="store_true", help="وضع التدفق")
    parser.add_argument("--interactive", "-i", action="store_true", help="وضع المحادثة التفاعلية")
    parser.add_argument("--model", help="اسم النموذج (يتجاوز WEAVER_MODEL)")
    parser.add_argument("--key", help="مفتاح API (يتجاوز WEAVER_API_KEY)")
    parser.add_argument("--url", help="عنوان API (يتجاوز WEAVER_BASE_URL)")

    args = parser.parse_args()

    # تطبيق الإعدادات من الأوامر
    if args.model:
        os.environ["WEAVER_MODEL"] = args.model
    if args.key:
        os.environ["WEAVER_API_KEY"] = args.key
    if args.url:
        os.environ["WEAVER_BASE_URL"] = args.url

    if args.interactive:
        asyncio.run(interactive_mode())
    elif args.prompt:
        asyncio.run(run_once(args.prompt, mode=args.mode, stream=args.stream))
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
